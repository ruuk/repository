script.bluray.com
=================

Kodi (XBMC) Addon for access to blu-ray.com features
----------------------------------------------------
It is currently only available on my [repository](http://ruuks-repo.googlecode.com/files/ruuk.addon.repository-1.0.0.zip).

Installation of the repository should be done through Kodi System::Settings::Add-ons::Install from zip file

Installation of the addon should be done through Kodi System::Settings::Add-ons::Get Add-Ons::All Add-Ons::Program Add-Ons::Blu-ray.com

Support is available at: http://forum.xbmc.org/showthread.php?tid=183667

Currently implemented blu-ray.com features:
  * Reviews
  * Releases
  * Search
  * Collection (Browse your blu-ray.com saved movie and game collection)
  * Price Track (View the status of you blu-ray.com price tracking)
