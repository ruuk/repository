# -*- coding: utf-8 -*-
import sys, xbmc

if __name__ == '__main__':
	arg = None
	if len(sys.argv) > 1: arg = sys.argv[1] or False
	if arg == 'TOGGLE':
		base = '{ "jsonrpc": "2.0", "method": "Addons.SetAddonEnabled", "params": { "addonid": "service.xbmc.tts","enabled":%s}, "id": 1 }'
		res = xbmc.executeJSONRPC(base % 'false') #Try to disable it
		if res and 'error' in res: #If we have an error, it's already disabled
			xbmc.executeJSONRPC(base % 'true') #So enable it instead