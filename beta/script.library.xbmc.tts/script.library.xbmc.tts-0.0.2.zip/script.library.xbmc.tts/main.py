# -*- coding: utf-8 -*-
import sys, xbmc

def getXBMCVersion():
	import json
	resp = xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Application.GetProperties", "params": {"properties": ["version", "name"]}, "id": 1 }')
	data = json.loads(resp)
	if not 'result' in data: return None
	if not 'version' in data['result']: return None
	return data['result']['version']
	
def main():
	arg = None
	if len(sys.argv) > 1: arg = sys.argv[1] or False
	if arg == 'TOGGLE':
		version = getXBMCVersion()
		if not version or version['major'] < 13: return
		base = '{ "jsonrpc": "2.0", "method": "Addons.SetAddonEnabled", "params": { "addonid": "service.xbmc.tts","enabled":%s}, "id": 1 }'
		res = xbmc.executeJSONRPC(base % 'false') #Try to disable it
		if res and 'error' in res: #If we have an error, it's already disabled
			xbmc.executeJSONRPC(base % 'true') #So enable it instead
			
if __name__ == '__main__':
	main()