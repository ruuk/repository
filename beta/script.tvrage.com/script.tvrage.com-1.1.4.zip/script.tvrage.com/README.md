script.tvrage.com
=================

Search and save a list of your favorite shows to be automatically updated and sorted by what's on next and highlighted for whats on today and tomorrow. Shows next and previous episode details. Select a show to browse and episode list.

Screenshots:
------------

[http://2ndmind.com/xbmc/pics/screenshot005.jpg]



[http://2ndmind.com/xbmc/pics/screenshot006.jpg]
