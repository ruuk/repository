# -*- coding: utf-8 -*-
import os
import xbmcaddon

ADDON_ID = 'script.module.oe.pi.extras'

def init():
    modPath = xbmcaddon.Addon(ADDON_ID).getAddonInfo('path')
    mpg321 = os.path.join(modPath,'usr','bin','mpg321')
    import subprocess
    subprocess.call('chmod +x {0}'.format(mpg321),shell=True)

def getEnvironment():
    modPath = xbmcaddon.Addon(ADDON_ID).getAddonInfo('path')
    libPath = ':' + os.path.join(modPath,'usr','lib')
    binPath = ':' + os.path.join(modPath,'usr','bin')
    env = os.environ

    if not binPath in env['PATH']:
        env['PATH'] += binPath
    if not libPath in env['LD_LIBRARY_PATH']:
        env['LD_LIBRARY_PATH'] += libPath

    return env
