# -*- coding: utf-8 -*-
import os
import xbmcaddon

ADDON_ID = 'script.module.op.pi.extras'

def getEnvironment():
    modPath = xbmcaddon.Addon(ADDON_ID).getAddonInfo('path')
    libPath = os.path.join(modPath,'usr','lib')
    binPath = os.path.join(modPath,'usr','bin')
    env = os.environ

    if not ADDON_ID in env['PATH']:
        env['PATH'] += ':' + binPath
    if not ADDON_ID in env['LD_LIBRARY_PATH']:
        env['LD_LIBRARY_PATH'] += ':' + libPath

    return env
